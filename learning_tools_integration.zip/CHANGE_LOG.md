** Version 3.3.38 **
* More intelligent use of tags, easier to develop custom templates.
* Bootstrap
* Bootbox modals
* Bug fixes

** Version 3.2.2 **
* Added BB_EMBED get parameter to allow embedding of tools in Blackboard
* using a token generated with the remember_lti_user plugin.
* Incorporated UoN Rails app for user creation of LTI links.

** Version 3.2.0 **
 fixed javascript bug in rubric

** Version 3.0.0 **
 Ajax endpoint for uploading rubrics from external tools
  New ACT category in extension hooks to allow direct action requests
 Link generation key added to blti_keys table for external link and template generation

** Version 2.24 **
 [Clickjack](https://www.owasp.org/index.php/Clickjacking) vulnerability has been addressed in this version
