<?php

return array(
      'author'      => 'Paul Sijpkes',
      'author_url'  => 'https://bold.newcastle.edu.au',
      'name'        => 'UoN Learning Tools Integration',
      'description' => 'University of Newcastle LTI tool launch and member management support',
      'version'     => '3.4.1',#build version#
      'namespace'   => 'Learning_tools_integration',
      'settings_exist' => TRUE,
);