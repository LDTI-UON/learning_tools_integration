<?php
/*
* Generate inline tags for instructor
*/
$launch_instructor = function($params) {
        $tag_data = $params['tag_data'];

        if($data = $this->random_form_error) {
              $params['tag_data']['random_form_error'] = $data;
        }

        return $params;
    };
?>
