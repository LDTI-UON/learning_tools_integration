<?php
$hook_method = function() {
    return isset($_REQUEST['custom_provide_solution']);
};

/*$launch_general = function($params) {
    $this->is_solution_request();

}*/
?>
